import UIKit

var myitemwidth = 0


class ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
    
        var itemArr = ["images-1","images-2","images-3","images-4","images-2","images-1","images-4","images-3","images-1","images-2",]

    @IBOutlet weak var myHeaderView: UIView!
    @IBOutlet weak var nextMoney: UILabel!
    @IBOutlet weak var nextPayLabel: UILabel!
    @IBOutlet weak var moneyLabel: UILabel!
    @IBOutlet weak var totalSpendLabel: UILabel!
    @IBOutlet weak var usernameLabel: UILabel!
    @IBOutlet weak var myCollectionView: UICollectionView!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        

        myCollectionView.collectionViewLayout = generateLayout()
        myCollectionView.delegate = self
        myCollectionView.dataSource = self
        myHeaderView.addBottomRoundedEdge(desiredCurve: 2.0)
        myHeaderView.frame = CGRect(x: 0, y: 0, width: view.frame.width+10, height: view.frame.height / 2)
        myHeaderView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: 0).isActive = true
        myHeaderView.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 0).isActive = true
        myHeaderView.bottomAnchor.constraint(equalTo: self.myHeaderView.topAnchor, constant: 205).isActive = true
        myHeaderView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 0).isActive = true
        myHeaderView.translatesAutoresizingMaskIntoConstraints = false
        
        
        myCollectionView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: 0).isActive = true
        myCollectionView.topAnchor.constraint(equalTo: self.myHeaderView.bottomAnchor, constant: -30).isActive = true
        myCollectionView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 0).isActive = true
        myCollectionView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: 0).isActive = true
        myCollectionView.translatesAutoresizingMaskIntoConstraints = false
        myCollectionView.register(FirstHeader.self, forSupplementaryViewOfKind: ViewController.firstID, withReuseIdentifier: headerId)
        myCollectionView.register(SecondHeader.self, forSupplementaryViewOfKind: ViewController.secondID, withReuseIdentifier: headerId)
        myCollectionView.register(ThirdHeader.self, forSupplementaryViewOfKind: ViewController.thirdID, withReuseIdentifier: headerId)
        
        
        usernameLabel.leadingAnchor.constraint(equalTo: self.myHeaderView.leadingAnchor, constant: 16).isActive = true
        usernameLabel.widthAnchor.constraint(equalToConstant: 150).isActive = true
        usernameLabel.heightAnchor.constraint(equalToConstant: 50).isActive = true
        usernameLabel.topAnchor.constraint(equalTo: self.myHeaderView.topAnchor, constant: 25).isActive = true
        usernameLabel.text = ("Hi Nishith N!")
        usernameLabel.font = UIFont.boldSystemFont(ofSize: 50)
        usernameLabel.textColor = .white
        usernameLabel.adjustsFontSizeToFitWidth = true
        usernameLabel.translatesAutoresizingMaskIntoConstraints = false
        
        
        totalSpendLabel.leadingAnchor.constraint(equalTo: self.myHeaderView.leadingAnchor, constant: 16).isActive = true
        totalSpendLabel.widthAnchor.constraint(equalToConstant: 150).isActive = true
        totalSpendLabel.heightAnchor.constraint(equalToConstant: 30).isActive = true
        totalSpendLabel.topAnchor.constraint(equalTo: self.usernameLabel.bottomAnchor, constant: 1).isActive = true
        totalSpendLabel.text = ("Total To Spend")
        totalSpendLabel.translatesAutoresizingMaskIntoConstraints = false
        totalSpendLabel.textColor = .white
        totalSpendLabel.adjustsFontSizeToFitWidth = true
        
        
        moneyLabel.leadingAnchor.constraint(equalTo: self.myHeaderView.leadingAnchor, constant: 16).isActive = true
        moneyLabel.widthAnchor.constraint(equalToConstant: 150).isActive = true
        moneyLabel.heightAnchor.constraint(equalToConstant: 30).isActive = true
        moneyLabel.topAnchor.constraint(equalTo: self.totalSpendLabel.bottomAnchor, constant: 1).isActive = true
        moneyLabel.text = ("£ 10.0")
        moneyLabel.font = UIFont.boldSystemFont(ofSize: 30)
        moneyLabel.textColor = .white
      
        moneyLabel.translatesAutoresizingMaskIntoConstraints = false
        
        
        nextPayLabel.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: 20).isActive = true
        nextPayLabel.widthAnchor.constraint(equalToConstant: 150).isActive = true
        nextPayLabel.heightAnchor.constraint(equalToConstant: 30).isActive = true
        nextPayLabel.topAnchor.constraint(equalTo: self.usernameLabel.bottomAnchor, constant: 1).isActive = true
        nextPayLabel.text = "Next Payment"
        nextPayLabel.translatesAutoresizingMaskIntoConstraints = false
        nextPayLabel.textColor = .white
        
        nextMoney.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant:42).isActive = true
        nextMoney.widthAnchor.constraint(equalToConstant: 150).isActive = true
        nextMoney.heightAnchor.constraint(equalToConstant: 30).isActive = true
        nextMoney.topAnchor.constraint(equalTo: self.nextPayLabel.bottomAnchor, constant: 1).isActive = true
        nextMoney.text = "£ 10.0"
        nextMoney.font = UIFont.boldSystemFont(ofSize: 30)
        nextMoney.translatesAutoresizingMaskIntoConstraints = false
        nextMoney.textColor = .white
      
    }
  
    
    func generateLayout() -> UICollectionViewLayout {
        return UICollectionViewCompositionalLayout { (sectionNumber, env) -> NSCollectionLayoutSection? in

             switch sectionNumber {

             case 0: return self.zeroLayoutSection()
             case 1: return self.firstLayoutSection()
             case 2: return self.secondLayoutSection()
             case 3: return self.thirdLayoutSection()
             default: return self.zeroLayoutSection()
             }
    }
    }

    
    private func zeroLayoutSection() -> NSCollectionLayoutSection {
        let item = NSCollectionLayoutItem.init(layoutSize: .init(widthDimension: .fractionalWidth(1), heightDimension: .fractionalHeight(1)))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: .init(widthDimension: .absolute((view.frame.size.width)-128), heightDimension: .absolute(200)), subitems: [item])
        let section = NSCollectionLayoutSection(group: group)
        section.orthogonalScrollingBehavior = .continuous
        section.contentInsets.leading = 64
        section.contentInsets.trailing = 64
        section.contentInsets.bottom = 16
        section.contentInsets.top = 50
        return section
    
    }
    private func firstLayoutSection() -> NSCollectionLayoutSection {
        let item = NSCollectionLayoutItem.init(layoutSize: .init(widthDimension: .fractionalWidth(1), heightDimension: .fractionalHeight(1)))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: .init(widthDimension: .fractionalWidth(0.75), heightDimension: .absolute(200)), subitems: [item])
        group.contentInsets.trailing = 16
        let section = NSCollectionLayoutSection(group: group)
        section.orthogonalScrollingBehavior = .continuous
        section.contentInsets.leading = 16
        section.contentInsets.bottom = 16
        section.boundarySupplementaryItems = [
            .init(layoutSize: .init(widthDimension: .fractionalWidth(1), heightDimension: .absolute(50)), elementKind: ViewController.firstID, alignment: .topLeading)
        ]
        
        return section
       
    }
    private func secondLayoutSection() -> NSCollectionLayoutSection {
        
        let item = NSCollectionLayoutItem.init(layoutSize: .init(widthDimension: .fractionalWidth(1), heightDimension: .fractionalHeight(1)))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: .init(widthDimension: .fractionalWidth(0.75), heightDimension: .absolute(200)), subitems: [item])
        group.contentInsets.trailing = 16
        let section = NSCollectionLayoutSection(group: group)
        section.orthogonalScrollingBehavior = .continuous
        section.contentInsets.leading = 16
        section.contentInsets.bottom = 16
        section.boundarySupplementaryItems = [
            .init(layoutSize: .init(widthDimension: .fractionalWidth(1), heightDimension: .absolute(50)), elementKind: ViewController.secondID, alignment: .topLeading)
        ]
        return section
    
       
    }
    private func thirdLayoutSection() -> NSCollectionLayoutSection {
        
        let item = NSCollectionLayoutItem.init(layoutSize: .init(widthDimension: .fractionalWidth(1), heightDimension: .fractionalHeight(1)))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: .init(widthDimension: .fractionalWidth(0.75), heightDimension: .absolute(200)), subitems: [item])
        group.contentInsets.trailing = 16
        let section = NSCollectionLayoutSection(group: group)
        section.orthogonalScrollingBehavior = .continuous
        section.contentInsets.leading = 16
        section.contentInsets.bottom = 50
        section.boundarySupplementaryItems = [
            .init(layoutSize: .init(widthDimension: .fractionalWidth(1), heightDimension: .absolute(50)), elementKind: ViewController.thirdID, alignment: .topLeading)
        ]
        return section
    
       
    }

    let headerId = "headerId"
    static let firstID = "firstID"
    static let secondID = "secondID"
    static let thirdID = "thirdID"
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 4
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        }
        else if section == 1
        {
            return 10
        }
        
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: headerId, for: indexPath)

        return header
    }
    
    
   
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "myCollectionCell", for: indexPath) as! myCollectionViewCell
        
        
        if indexPath.section == 0{
        cell.myImage.image = UIImage(named: "Image")
            cell.contentView.layer.cornerRadius = 20.0
            cell.contentView.clipsToBounds = true
            cell.myLabel.font = UIFont.boldSystemFont(ofSize: 25)
        cell.myLabel.textAlignment = .center
            cell.myLabel.text = "Apply Today!"
       
            
        }
        else if indexPath.section == 1{
            
        cell.myImage.image = UIImage(named: "\(itemArr[indexPath.row])")
            cell.contentView.layer.cornerRadius = 20.0
            cell.contentView.clipsToBounds = true
            
            
        
            cell.myImage.leadingAnchor.constraint(equalTo: cell.myView.leadingAnchor, constant: 0).isActive = true
            cell.myImage.trailingAnchor.constraint(equalTo: cell.myView.trailingAnchor, constant: 0).isActive = true
            cell.myImage.translatesAutoresizingMaskIntoConstraints = false
            cell.myView.translatesAutoresizingMaskIntoConstraints = false
           
         
            cell.myImage.topAnchor.constraint(equalTo: cell.myView.topAnchor, constant: 0).isActive = true
            cell.myImage.bottomAnchor.constraint(equalTo: cell.myView.bottomAnchor, constant: 0).isActive = true
            cell.myImage.heightAnchor.constraint(equalToConstant: 200).isActive = true
        
            cell.myView.heightAnchor.constraint(equalToConstant: 200).isActive = true
            
        cell.myLabel.textAlignment = .center
            cell.myLabel.font = UIFont.boldSystemFont(ofSize: 25)
        cell.myLabel.frame = CGRect(x: cell.myView.frame.size.width/2, y: cell.myView.frame.size.height/2, width: 150, height: 30)
        }
        else if indexPath.section == 2{
            cell.contentView.layer.cornerRadius = 20.0
            cell.contentView.clipsToBounds = true
            cell.myLabel.text = "Steray87"
        cell.myImage.image = UIImage(named: "\(itemArr[indexPath.row])")
            
            cell.myImage.leadingAnchor.constraint(equalTo: cell.myView.leadingAnchor, constant: 0).isActive = true
            cell.myImage.trailingAnchor.constraint(equalTo: cell.myView.trailingAnchor, constant: 0).isActive = true
            cell.myImage.translatesAutoresizingMaskIntoConstraints = false
            cell.myImage.bottomAnchor.constraint(equalTo: cell.myView.bottomAnchor, constant: 0).isActive = true
            cell.myImage.heightAnchor.constraint(equalToConstant: 200).isActive = true
            cell.myLabel.font = UIFont.boldSystemFont(ofSize: 25)
        cell.myLabel.textAlignment = .center
        cell.myLabel.frame = CGRect(x: cell.myView.frame.size.width/2, y: cell.myView.frame.size.height/2, width: 150, height: 30)
        }
        else if indexPath.section == 3{
            cell.contentView.layer.cornerRadius = 20.0
            cell.contentView.clipsToBounds = true
        cell.myImage.image = UIImage(named: "\(itemArr[indexPath.row])")
            cell.myLabel.text = "KT Demo Account"
            cell.myImage.leadingAnchor.constraint(equalTo: cell.myView.leadingAnchor, constant: 0).isActive = true
            cell.myImage.trailingAnchor.constraint(equalTo: cell.myView.trailingAnchor, constant: 0).isActive = true
            cell.myImage.translatesAutoresizingMaskIntoConstraints = false
            cell.myImage.bottomAnchor.constraint(equalTo: cell.myView.bottomAnchor, constant: 0).isActive = true
            cell.myImage.heightAnchor.constraint(equalToConstant: 200).isActive = true
            cell.myLabel.font = UIFont.boldSystemFont(ofSize: 25)
        cell.myLabel.textAlignment = .center
        cell.myLabel.frame = CGRect(x: cell.myView.frame.size.width/2, y: cell.myView.frame.size.height/2, width: 150, height: 30)
        }
       

        else{
            cell.myImage.image = UIImage(named: "\(itemArr[indexPath.row])")
           cell.backgroundColor = .green
            cell.myLabel.textAlignment = .center
            cell.myLabel.font = UIFont.boldSystemFont(ofSize: 25)
            cell.myLabel.frame = CGRect(x: cell.myView.frame.size.width/2, y: cell.myView.frame.size.height/2, width: 150, height: 30)
        }
    
        return cell
    }
    }

class FirstHeader: UICollectionReusableView {
    let firstlabel = UILabel()
    let secondlabel = UILabel()
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(firstlabel)
        addSubview(secondlabel)
    }
    
    override func layoutSubviews() {
        firstlabel.text = "AGRICULTURE"
        firstlabel.textColor = .black
        super.layoutSubviews()
        firstlabel.frame = CGRect(x: 0, y: 0, width: 150, height: 30)
        secondlabel.text = "Just some of our amazing Agriculture partners"
        secondlabel.adjustsFontSizeToFitWidth = true
        secondlabel.frame = CGRect(x: 0, y: 20, width: 230, height: 30)
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

class SecondHeader: UICollectionReusableView {
    let firstlabel = UILabel()
    let secondlabel = UILabel()
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(firstlabel)
        addSubview(secondlabel)
    }
    
    override func layoutSubviews() {
        firstlabel.text = "APPAREL"
        firstlabel.textColor = .black
        super.layoutSubviews()
        firstlabel.frame = CGRect(x: 0, y: 0, width: 150, height: 30)
        secondlabel.text = "Just some of our amazing Apparel partners"
        secondlabel.adjustsFontSizeToFitWidth = true
        secondlabel.frame = CGRect(x: 0, y: 20, width: 230, height: 30)
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

class ThirdHeader: UICollectionReusableView {
    let firstlabel = UILabel()
    let secondlabel = UILabel()
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(firstlabel)
        addSubview(secondlabel)
    }
    
    override func layoutSubviews() {
        firstlabel.text = "BANKING"
        firstlabel.textColor = .black
        super.layoutSubviews()
        firstlabel.frame = CGRect(x: 0, y: 0, width: 150, height: 30)
        secondlabel.text = "Just some of our amazing Banking partners"
        secondlabel.adjustsFontSizeToFitWidth = true
        secondlabel.frame = CGRect(x: 0, y: 20, width: 230, height: 30)
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


    

extension UIView {

func addBottomRoundedEdge(desiredCurve: CGFloat?) {
let offset: CGFloat = self.frame.width / desiredCurve!
let bounds: CGRect = self.bounds

    let rectBounds: CGRect = CGRect(x: bounds.origin.x, y: bounds.origin.y, width: bounds.size.width+10, height: bounds.size.height / 2)
let rectPath: UIBezierPath = UIBezierPath(rect: rectBounds)
let ovalBounds: CGRect = CGRect(x: (bounds.origin.x - offset / 2)-10, y: bounds.origin.y, width: bounds.size.width + offset, height: bounds.size.height)
let ovalPath: UIBezierPath = UIBezierPath(ovalIn: ovalBounds)
        rectPath.append(ovalPath)
// Create the shape layer and set its path
        let maskLayer: CAShapeLayer = CAShapeLayer()
        maskLayer.frame = bounds
        maskLayer.path = rectPath.cgPath
    maskLayer.cornerRadius = 25
    
   
// Set the newly created shape layer as the mask for the view's layer
        self.layer.mask = maskLayer
    }
}




 
