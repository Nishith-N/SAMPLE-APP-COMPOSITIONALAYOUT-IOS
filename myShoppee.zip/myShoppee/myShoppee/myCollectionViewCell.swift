//
//  myCollectionViewCell.swift
//  myShoppee
//
//  Created by Anilkumar on 14/06/22.
//

import UIKit

class myCollectionViewCell: UICollectionViewCell {
    
   
    
    
    @IBOutlet weak var myView: UIView!
    
    
    @IBOutlet weak var myLabel: UILabel!
    @IBOutlet weak var myImage: UIImageView!
    
    
    
    
    
    
}
